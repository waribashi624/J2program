void list_main(void)
{


  Str list[sizeof(str)];
  Str* pt = list;
  int i = 0;
  
  pt->pre = NULL;

  while(i < sizeof(str)){
    (pt->sentence) = str[i];
    (pt->next)->pre = pt;
    if(i == sizeof(str) - 1){
      (pt->next) = NULL;
    }else{
      (pt->next) = &list[i+1];
    }
    next_pt(pt,1);i++;
  }

}


void list_disp(Str* pt){
 
  while(1){
    if(pt->next == NULL){
    printf("%c",pt->sentence);
    break;
    }
    printf("%c",pt->sentence);
    pt = pt-next;
  }

}


void list_change(Str* pt)
{

  int i = 0;
  int t = 0;
  int count = 0;
  char target[] = "AGCTTA";
  Str* temp;
  
  while(pt->next != NULL){
    if(target[t] == list.sentence[i]){
      if(t == 5){
      	pre_pt(pt,5);
	
	while(i < 3){
	temp = (Str*)malloc(sizeof(Str));
	temp->sentence = 'A';
	pt->next = temp;
	next(pt,1);
	  }




	next_pt(pt,1);
	count++;
	t = 0;
      }else{
	t++;
      }
    }else{
      if(t != 0){
	i -= t;
	t = 0;
      }else{
	t = 0;
      }
    }
    i++;
  }

  printf("count = %d",count);


}


Str* pre_pt(Str* pt,int num)
{
  int i = 0;
  while(i < num){
  pt = pt->pre;
  i++;
  }
  return pt;
}


Str* next_pt(Str* pt,int num)
{
  int i = 0;
  while(i < num){
    pt = pt->next;
    i++;
  }
  return 0;
}
